DIST_ZANAHORIA = 0.0 # La zanahoria esta en el mismo lugar que la coordenada

# Es la distancia que separa a la zanahoria del punto real
VEL_LINEAL = 0.1
DIST_CAMBIO = 0.6

Kp = 3
Ki = 1.5
Kd = 0.05

# Kp = 3
# Ki = 1
# Kd = 0

#RUTA_ARCHIVO = "path_line.txt"
RUTA_ARCHIVO = "path_sin.txt"        
#RUTA_ARCHIVO = "path_sqrt.txt"
        
    
